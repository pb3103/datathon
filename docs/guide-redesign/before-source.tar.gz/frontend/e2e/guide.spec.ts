import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('Guide: pretraga, sinonimi, izvori, oporavak i karta', async ({ page }) => {
  await page.goto('/');
  await page
    .getByRole('navigation', { name: 'Moduli' })
    .getByRole('link', { name: 'Waste Guide', exact: true })
    .click();
  await expect(page.getByRole('heading', { name: 'Male navike. Velike promjene.' })).toBeVisible();
  const search = page.getByLabel('Predmet ili materijal');
  await search.fill('RACUNALO');
  await page.getByRole('button', { name: /Laptop/ }).click();
  await expect(page.locator('#item-title')).toHaveText('Laptop');
  await expect(page.locator('.guide-item a[target="_blank"]')).toHaveAttribute('href', /gov.hr/);
  await page.reload();
  await expect(page.locator('#item-title')).toHaveText('Laptop');
  await page.getByRole('button', { name: 'Očisti', exact: true }).click();
  await expect(search).toBeFocused();
  await search.fill('xxyyzz');
  await expect(page.getByText('Nema rezultata', { exact: false })).toBeVisible();
  await search.fill('baterija');
  await page.getByRole('button', { name: /Prijenosna baterija/ }).click();
  await expect(page.getByText(/ne potvrđuje da pojedina lokacija/)).toBeVisible();
  await page.getByRole('link', { name: /Pronađi mjesto za odlaganje/ }).click();
  await expect(page).toHaveURL(/\/#waste-map$/);
  await expect(page.locator('#waste-map')).toBeInViewport();
  await expect(page.locator('.leaflet-container')).toBeVisible();
  await page.goto('/guide?predmet=nepostoji');
  await expect(page.locator('#item-title')).toHaveText('Uputa na jednom mjestu');
});

test('Guide: hijerarhija, tematske poveznice i lokalne upute', async ({ page }) => {
  await page.goto('/guide');
  await page.getByRole('button', { name: /03Recikliranje|03 Recikliranje/ }).click();
  await expect(page.locator('#hierarchy-detail h3')).toHaveText('Recikliranje');
  await page
    .locator('.guide-topic-grid article')
    .filter({ hasText: 'Tekstil' })
    .getByRole('link', { name: 'Provjeri odlaganje →' })
    .click();
  await expect(page.locator('#item-title')).toHaveText('Majica');
  await page.getByLabel('Predmet ili materijal').fill('staklenka');
  await page.getByRole('button', { name: /Staklenka/ }).click();
  await expect(page.locator('.guide-item')).toContainText(
    'Način predaje i boju spremnika provjerite',
  );
  await expect(page.locator('.guide-item')).not.toContainText('Lokalna uputa: Zagreb');
});

test('Guide: kviz zaključava odgovor, računa rezultat i resetira se', async ({ page }) => {
  await page.goto('/guide#kviz');
  const quiz = page.locator('.guide-quiz');
  await expect(quiz.getByRole('button', { name: 'Provjeri odgovor' })).toBeDisabled();
  for (const [index, answer] of [0, 0, 2, 1, 0, 2].entries()) {
    await quiz.getByRole('radio').nth(answer).check();
    await quiz.getByRole('button', { name: 'Provjeri odgovor' }).click();
    await expect(quiz.getByRole('radio').first()).toBeDisabled();
    await expect(quiz.getByRole('status')).toContainText(index === 1 ? 'Točan odgovor:' : 'Točno.');
    await quiz
      .getByRole('button', { name: index === 5 ? 'Prikaži rezultat' : 'Sljedeće pitanje' })
      .click();
  }
  await expect(quiz.getByRole('heading')).toHaveText('5 od 6 točnih odgovora');
  await quiz.getByRole('button', { name: 'Pokušaj ponovno' }).click();
  await expect(quiz).toContainText('Pitanje 1 od 6');
  await expect(quiz.getByRole('button', { name: 'Provjeri odgovor' })).toBeDisabled();
});

for (const [width, height] of [
  [1440, 1000],
  [820, 1180],
  [390, 844],
  [320, 844],
]) {
  test(`Guide: prikaz i pristupačnost ${width}`, async ({ page }) => {
    await page.setViewportSize({ width, height });
    await page.goto('/guide?predmet=stedna-zarulja');
    await expect(page.locator('#item-title')).toHaveText('Štedna žarulja');
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
    ).toBeTruthy();
    const results = await new AxeBuilder({ page }).analyze();
    expect(results.violations).toEqual([]);
    await page.screenshot({ path: `/app/test-results/guide-top-${width}.png` });
    await page.screenshot({ path: `/app/test-results/guide-${width}.png`, fullPage: true });
    await page.getByRole('link', { name: 'Provjerite znanje', exact: true }).click();
    await page.locator('.guide-quiz input').first().focus();
    await page.keyboard.press('Space');
    await expect(page.locator('.guide-quiz input').first()).toBeChecked();
  });
}

test('Guide: tematske slike se učitavaju, naslov prati Home i sadržaj je očuvan', async ({
  page,
}) => {
  for (const width of [1440, 820, 390]) {
    await page.setViewportSize({ width, height: 1000 });
    await page.goto('/');
    const homeSize = await page
      .locator('#page-title')
      .evaluate((element) => getComputedStyle(element).fontSize);
    await page.goto('/guide');
    await expect(page.locator('#page-title')).toHaveCSS('font-size', homeSize);
    const hero = page.locator('.guide-hero-visual img');
    await expect
      .poll(() => hero.evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0))
      .toBe(true);
    const photos = page.locator('.guide-topic-photo');
    await expect(photos).toHaveCount(4);
    for (const photo of await photos.all()) {
      await photo.scrollIntoViewIfNeeded();
      await expect
        .poll(() => photo.evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0))
        .toBe(true);
    }
    const allImages = page.locator('.guide-hero img, .guide-page img');
    await expect(allImages).toHaveCount(9);
    const imageUrls = await allImages.evaluateAll((images) =>
      images.map((image) => image.getAttribute('src')),
    );
    expect(new Set(imageUrls).size).toBe(imageUrls.length);
    for (const image of await allImages.all()) {
      await image.scrollIntoViewIfNeeded();
      await expect
        .poll(() => image.evaluate((img: HTMLImageElement) => img.complete && img.naturalWidth > 0))
        .toBe(true);
    }
    await expect(page.locator('.guide-fact')).toHaveCount(6);
    await expect(page.locator('.guide-fact .guide-source')).toHaveCount(6);
    await page
      .locator('#cinjenice')
      .evaluate((element) => element.scrollIntoView({ block: 'start' }));
    await page.screenshot({ path: `/app/test-results/guide-facts-${width}.png` });
    await page
      .locator('#prevencija')
      .evaluate((element) => element.scrollIntoView({ block: 'start' }));
    await page.screenshot({ path: `/app/test-results/guide-prevention-${width}.png` });
  }
});

test('Guide: povezane upute su zasebne od rezultata i odabir se ažurira', async ({ page }) => {
  await page.goto('/guide');
  const search = page.getByLabel('Predmet ili materijal');
  await search.fill('MOBILNI TELEFON');
  await page
    .locator('.guide-results')
    .getByRole('button', { name: /Mobitel/ })
    .click();
  await expect(page.locator('.guide-results li')).toHaveCount(1);
  await expect(page.locator('.guide-results button')).toHaveAttribute('aria-pressed', 'true');
  await expect(page.locator('.guide-results')).toContainText('Odabrano');
  const related = page.getByRole('group', { name: 'Možda vas zanima i' });
  await expect(related.getByRole('button')).toHaveCount(3);
  await expect(related).toContainText('Punjač');
  await expect(related).toContainText('Prijenosna baterija');
  await related.getByRole('button', { name: /Punjač/ }).focus();
  await page.keyboard.press('Enter');
  await expect(page.locator('#item-title')).toHaveText('Punjač');
  await expect(search).toHaveValue('Punjač');
  await expect(page).toHaveURL(/predmet=punjac/);
  await expect(page.locator('#item-title')).toBeFocused();
  await page.getByRole('button', { name: 'Očisti', exact: true }).click();
  await expect(related).toHaveCount(0);
  await search.fill('istekli lijekovi');
  await page.locator('.guide-results button').click();
  await expect(related).toHaveCount(0);
  await expect(page.locator('.guide-item')).toContainText('Ljekarna');
});

test('Guide: PPWR, statistika i razlikovanje ponovne uporabe imaju provjerljive izvore', async ({
  page,
}) => {
  await page.goto('/guide');
  const ppwr = page.getByRole('article', { name: 'PPWR — nova europska pravila za ambalažu' });
  await expect(ppwr.locator('time[datetime="2025-02-11"]')).toHaveText('11. veljače 2025.');
  await expect(ppwr.locator('time[datetime="2026-08-12"]')).toHaveText('12. kolovoza 2026.');
  await expect(ppwr).toContainText('Pojedine obveze imaju zasebne rokove');
  await expect(ppwr.locator('a').first()).toHaveAttribute(
    'href',
    'https://eur-lex.europa.eu/eli/reg/2025/40/oj',
  );
  const food = page.getByRole('article', { name: 'Otpad od hrane u Hrvatskoj' });
  await expect(food.locator('.guide-stat-number')).toContainText('57,3');
  await expect(food).toContainText('2025. · kućanstva');
  await expect(food).toContainText('jestivi i nejestivi');
  await food.getByText('Obuhvat istraživanja', { exact: true }).click();
  await expect(food).toContainText('Ne uključuje poslovni sektor');
  await expect(food.locator('a').first()).toHaveAttribute('href', /ver_5.pdf#page=5$/);
  await page.getByRole('button', { name: /02.*Priprema za ponovnu uporabu/ }).click();
  await expect(page.locator('#hierarchy-detail')).toContainText('već postao otpad');
  await expect(page.locator('#hierarchy-detail')).toContainText('nije postao otpad');
  for (const [width, height] of [
    [1440, 1000],
    [820, 1180],
    [390, 844],
    [320, 844],
  ]) {
    await page.setViewportSize({ width, height });
    await ppwr.evaluate((element) => element.scrollIntoView({ block: 'start' }));
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
      true,
    );
    await expect(ppwr).toBeVisible();
    await page.screenshot({ path: `/app/test-results/guide-ppwr-${width}.png` });
  }
});

test('Guide: pet sidara i sve poveznice registra izvora otvaraju odgovarajuće odredište', async ({
  page,
  context,
}) => {
  await page.goto('/guide');
  const nav = page.getByRole('navigation', { name: 'Dijelovi vodiča' });
  for (const link of await nav.getByRole('link').all()) {
    const hash = await link.getAttribute('href');
    await link.click();
    expect(new URL(page.url()).hash).toBe(hash);
    await expect(page.locator(hash!)).toBeInViewport();
  }
  const registry = page.locator('.guide-maintenance details');
  await registry.locator('summary').click();
  const links = registry.locator('a');
  await expect(links).toHaveCount(17);
  // Verify new-tab navigation without making the test depend on third-party uptime.
  // Actual source content and availability were checked separately during the audit.
  await context.route(/^https:\/\//, (route) =>
    route.fulfill({
      status: 200,
      contentType: 'text/html',
      body: '<title>Provjera odredišta izvora</title>',
    }),
  );
  for (const link of await links.all()) {
    const destination = await link.getAttribute('href');
    await expect(link).toHaveAttribute('target', '_blank');
    const popupPromise = page.waitForEvent('popup');
    await link.click();
    const popup = await popupPromise;
    await expect(popup).toHaveURL(destination!);
    await popup.close();
  }
});
