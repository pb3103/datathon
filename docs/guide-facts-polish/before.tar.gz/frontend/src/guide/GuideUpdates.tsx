import { foodStatistic } from './content';
import { Source } from './GuideSources';

export function PackagingRegulation() {
  return (
    <details className="guide-ppwr guide-eu-accordion">
      <summary>
        <div>
          <span className="guide-ppwr-kicker">EU UREDBA · AMBALAŽA</span>
          <h3 id="ppwr-title">PPWR — nova pravila za ambalažu</h3>
          <p>Manje ambalažnog otpada, više ponovne uporabe i bolja mogućnost recikliranja.</p>
        </div>
        <span className="guide-ppwr-control" aria-hidden="true">
          <span className="guide-ppwr-open-label">Saznaj više</span>
          <span className="guide-ppwr-close-label">Sažmi</span>
          <svg className="guide-eu-expand" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path
              d="m5 7.5 5 5 5-5"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </summary>
      <div className="guide-eu-accordion-body">
        <div className="guide-ppwr-main">
          <p className="guide-ppwr-section-label">Što se mijenja</p>
          <p>
            Uredba (EU) 2025/40 uvodi pravila za smanjenje ambalažnog otpada, poticanje ponovne
            uporabe i poboljšanje mogućnosti recikliranja ambalaže.
          </p>
          <div className="guide-ppwr-ideas">
            <div>
              <div>
                <h4>Manje nepotrebne ambalaže</h4>
                <p>Manje materijala i sprječavanje nastanka otpada.</p>
              </div>
            </div>
            <div>
              <div>
                <h4>Više ponovne uporabe</h4>
                <p>Višekratna rješenja gdje je primjenjivo.</p>
              </div>
            </div>
            <div>
              <div>
                <h4>Bolja mogućnost recikliranja</h4>
                <p>Dizajn ambalaže koji olakšava obradu.</p>
              </div>
            </div>
          </div>
          <p>
            Pravila postupno utječu na ambalažu proizvoda koje kupujemo, njezino označavanje i
            mogućnosti ponovne uporabe.
          </p>
        </div>
        <div className="guide-ppwr-timing">
          <p className="guide-ppwr-section-label">Ključni datumi</p>
          <dl className="guide-ppwr-dates">
            <div>
              <dt>Stupanje na snagu</dt>
              <dd>
                <time dateTime="2025-02-11">11. veljače 2025.</time>
              </dd>
            </div>
            <div>
              <dt>Početak opće primjene</dt>
              <dd>
                <time dateTime="2026-08-12">12. kolovoza 2026.</time>
              </dd>
            </div>
          </dl>
          <p className="guide-small">
            Pojedine obveze imaju zasebne rokove i uvode se postupno, ovisno o odredbi.
          </p>
        </div>
        <div className="guide-ppwr-sources">
          <Source id="ppwr" />
          <Source id="packagingEu" />
        </div>
      </div>
    </details>
  );
}

export function FoodStatistic() {
  return (
    <article className="guide-food-statistic" aria-labelledby="food-statistic-title">
      <header className="guide-stat-heading">
        <h3 id="food-statistic-title">Otpad od hrane u Hrvatskoj</h3>
        <span className="guide-stat-year">{foodStatistic.referenceYear}. · kućanstva</span>
      </header>
      <p className="guide-stat-number">
        <strong>{foodStatistic.value}</strong>
        <span>{foodStatistic.unit}</span>
      </p>
      <div className="guide-stat-copy">
        <p>{foodStatistic.scope}</p>
        <p className="guide-action">
          <span aria-hidden="true">↳</span> {foodStatistic.tip}
        </p>
        <Source id={foodStatistic.source} />
        <details className="guide-stat-details">
          <summary>Obuhvat istraživanja</summary>
          <p>
            {foodStatistic.methodology} Izvješće je objavljeno {foodStatistic.publicationYear}.
          </p>
        </details>
      </div>
    </article>
  );
}

export function GreenDeal() {
  return (
    <details className="guide-green-deal guide-eu-accordion">
      <summary>
        <div>
          <span className="guide-ppwr-kicker">EU STRATEGIJA · ODRŽIVOST</span>
          <h3>Europski zeleni plan — prema održivijoj Europi</h3>
          <p>
            Europska strategija za klimatski neutralno gospodarstvo, učinkovitiju uporabu resursa i
            manje otpada.
          </p>
        </div>
        <span className="guide-ppwr-control" aria-hidden="true">
          <span className="guide-ppwr-open-label">Saznaj više</span>
          <span className="guide-ppwr-close-label">Sažmi</span>
          <svg className="guide-eu-expand" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path
              d="m5 7.5 5 5 5-5"
              stroke="currentColor"
              strokeWidth="1.7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </summary>
      <div className="guide-eu-accordion-body guide-green-body">
        <div className="guide-green-intro">
          <h4>Što je Europski zeleni plan?</h4>
          <p>
            Europski zeleni plan pokrenut je 2019. kao skup političkih inicijativa EU-a za zelenu
            tranziciju. Dugoročni je cilj klimatska neutralnost Europe do 2050., uz promjene načina
            proizvodnje i potrošnje. Riječ je o širem političkom i strateškom okviru, a ne o jednom
            propisu.
          </p>
        </div>
        <div className="guide-green-goals" aria-label="Ključni ciljevi Zelenog plana">
          <div>
            <h4>Klimatska neutralnost do 2050.</h4>
            <p>
              Smanjenje emisija stakleničkih plinova i prijelaz prema klimatski neutralnom
              gospodarstvu.
            </p>
          </div>
          <div className="guide-green-circular">
            <span className="guide-ppwr-kicker">POSEBNO VAŽNO ZA WASTEWISE</span>
            <h4>Kružno gospodarstvo</h4>
            <p>
              Proizvodi se dulje koriste, popravljaju, ponovno upotrebljavaju i recikliraju, čime se
              smanjuje otpad i štede resursi.
            </p>
          </div>
          <div>
            <h4>Čišći i zdraviji okoliš</h4>
            <p>Smanjenje onečišćenja i zaštita prirode i zdravlja ljudi.</p>
          </div>
        </div>
        <div className="guide-green-practice">
          <h4>Što to znači za gospodarenje otpadom?</h4>
          <p>
            Za WasteWise je posebno važan prijelaz s modela „proizvedi — iskoristi — odbaci” na
            kružni pristup, u kojem se nastoji spriječiti nastanak otpada, produljiti vijek
            proizvoda i sačuvati vrijednost materijala.
          </p>
          <ol className="guide-green-steps">
            <li>Smanji nepotrebnu potrošnju.</li>
            <li>Popravi i ponovno upotrijebi.</li>
            <li>Pravilno odvoji otpad.</li>
            <li>Omogući oporabu i recikliranje materijala.</li>
          </ol>
          <p className="guide-small">Samo odvajanje otpada ne jamči recikliranje.</p>
        </div>
        <p className="guide-green-connection">
          PPWR je primjer konkretnog zakonodavnog okvira povezanog sa širim europskim nastojanjima
          za kružnije gospodarstvo i održiviju ambalažu. Zeleni plan sam po sebi ne propisuje sve
          ciljeve recikliranja prikazane iznad.
        </p>
        <div className="guide-ppwr-sources">
          <Source id="greenDeal" />
        </div>
      </div>
    </details>
  );
}
